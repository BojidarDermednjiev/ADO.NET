﻿namespace BookShop.Common
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=ADMINISTRATOR\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;TrustServerCertificate=True";
    }
}
