﻿namespace BookShop.Models.Enum
{
    public enum AgeRestriction
    {
        Minor = 0,
        Teen = 1,
        Adult = 2
    }
}
