﻿namespace BookShop.Models
{
    using Microsoft.EntityFrameworkCore;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    
    using Enum;
    using Common;
    public class Book
    {
        public Book()
        {
            this.BookCategories = new HashSet<BookCategory>();
        }

        public int BookId { get; set; }

        [Unicode]
        [MaxLength(ValidationConstants.BookMaxLengthTitle)]
        public string Title { get; set; } 

        [Unicode]
        [MaxLength(ValidationConstants.BookMaxLengthDescription)]
        public string Description { get; set; } 

        public DateTime? ReleaseDate { get; set; }
        public int Copies { get; set; }
        public decimal Price { get; set; }
        public EditionType EditionType { get; set; }
        public AgeRestriction AgeRestriction { get; set; }
        public int AuthorId { get; set; }
        public Author Author { get; set; }
        public virtual ICollection<BookCategory> BookCategories { get; set; } = null!;
    }
}
